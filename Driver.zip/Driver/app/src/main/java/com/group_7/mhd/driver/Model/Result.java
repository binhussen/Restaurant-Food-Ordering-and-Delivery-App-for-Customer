package com.group_7.mhd.driver.Model;

public class Result {
    public String message;
}
