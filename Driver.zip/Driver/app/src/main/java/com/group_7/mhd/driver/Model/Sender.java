package com.group_7.mhd.driver.Model;

public class Sender {
    public Sender(String token, Notification notification) {
    }
}
